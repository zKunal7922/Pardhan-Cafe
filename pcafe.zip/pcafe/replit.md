# Pradhan Cafe - Ordering System

## Overview
This is a PHP-based cafe ordering system that allows customers to browse menu items, add them to cart, and place orders. It includes an admin panel for managing orders.

## Project Architecture
- **Frontend**: PHP with HTML/CSS serving dynamic content
- **Backend**: PHP with SQLite database
- **Database**: SQLite (auto-initializes with sample data)
- **Server**: PHP built-in development server

## Structure
- `index.php` - Entry point (redirects to public/index.php)
- `public/` - Main application directory
  - `index.php` - Main menu page
  - `cart.php` - Shopping cart functionality
  - `place_order.php` - Order placement
  - `order_success.php` - Order confirmation
  - `assets/css/style.css` - Application styling
- `admin/` - Admin panel
  - `login.php` - Admin authentication (default: admin/1234)
  - `dashboard.php` - Admin dashboard
  - `order.php` - Order management
- `db/` - Database setup
  - `init.php` - Database initialization and helper functions
  - `cafedb.sqlite` - SQLite database file

## Recent Changes (September 9, 2025)
- Set up PHP environment in Replit
- Configured PHP development server on port 5000
- Verified database initialization with sample menu items
- Configured deployment for autoscale target
- All core functionality tested and working

## Current State
✅ Application running successfully on port 5000
✅ Database initialized with sample data
✅ Admin panel accessible
✅ Cart and ordering functionality working
✅ Deployment configured for production

## Admin Access
- Username: admin (configurable via ADMIN_USER env var)
- Password: 1234 (configurable via ADMIN_PASS env var)

## Sample Data
The application comes with sample menu items:
- Brain Attacker: Ice Tea (₹79)
- Shakes: Oreo Shake (₹90)
- Coffee: Cold Coffee (₹49)
- Burger: Veg. Burger (₹59)