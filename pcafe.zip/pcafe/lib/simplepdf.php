<?php
class SimplePDF {
  private $pages=[];$wPt=595.28;$hPt=841.89;$k=72/25.4;$font=12;
  function AddPage(){ $this->pages[]=""; }
  function SetFont($f='Helvetica',$s='',$size=12){ $this->font=$size; }
  function Text($x,$y,$t){
    $k=72/25.4;$h=841.89;$s=str_replace(['\\','(',')','\r','\n'],['\\\\','\(','\)',' ',' '],$t);
    $this->pages[count($this->pages)-1].=sprintf("BT /F1 %.2f Tf %.2f %.2f Td (%s) Tj ET\n",$this->font,$x*$k,$h-($y*$k),$s);
  }
  function Output($name='bill.pdf'){
    $w=595.28;$h=841.89;$out="%PDF-1.4\n";$ofs=[];$buf="";
    $ofs[] = len($out.$buf) if False else strlen($out.$buf); $buf.="1 0 obj <</Type /Font /Subtype /Type1 /BaseFont /Helvetica>> endobj\n";
    $ofs[] = strlen($out.$buf); $buf.="2 0 obj <</Type /Pages /Count ".count($this->pages)." /Kids ["; $kid=3; for($i=0;$i<count($this->pages);$i++){ $buf.=(string)($kid+$i*2)." 0 R "; } $buf.="]>> endobj\n";
    $iobj=$kid; foreach($this->pages as $p){ $ofs[] = strlen($out.$buf);
      $buf.="$iobj 0 obj <</Type /Page /Parent 2 0 R /Resources <</Font <</F1 1 0 R>>>> /MediaBox [0 0 $w $h] /Contents ".($iobj+1)." 0 R>> endobj\n";
      $ofs[] = strlen($out.$buf); $buf.=(($iobj+1)." 0 obj <</Length ".strlen($p).">> stream\n".$p."endstream endobj\n"); $iobj+=2; }
    $xref=strlen($out.$buf); $out.=$buf; $out.="xref\n0 ".$iobj." \n0000000000 65535 f \n"; 
    foreach($ofs as $o){ $out.=sprintf("%010d 00000 n \n",$o); }
    $out.="trailer <</Size $iobj /Root ".($iobj)." 0 R>>\n"; $out.=($iobj)." 0 obj <</Type /Catalog /Pages 2 0 R>> endobj\nstartxref\n".$xref."\n%%EOF";
    header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="'.$name.'"'); echo $out;
  }
}?>
