<?php
require_once __DIR__.'/../../db/init.php';

// Set headers for Server-Sent Events
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('Access-Control-Allow-Origin: *');

// Prevent timeout
set_time_limit(0);
ini_set('auto_detect_line_endings', 1);

$pdo = db();
$lastCheck = time();
$maxIterations = 60; // Run for ~2-4 minutes
$sleepInterval = 3; // seconds

for ($i = 0; $i < $maxIterations; $i++) {
    try {
        // Get latest orders with status and timing
        $orders = $pdo->query("
            SELECT o.*, 
                   COUNT(oi.id) as item_count,
                   GROUP_CONCAT(oi.item_name || ' x' || oi.qty) as items_summary
            FROM orders o 
            LEFT JOIN order_items oi ON o.id = oi.order_id 
            GROUP BY o.id 
            ORDER BY o.created_at DESC 
            LIMIT 50
        ")->fetchAll();

        // Get summary stats
        $stats = $pdo->query("
            SELECT 
                COUNT(*) as total_orders,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                COUNT(CASE WHEN status = 'preparing' THEN 1 END) as preparing_count,
                COUNT(CASE WHEN status = 'served' THEN 1 END) as served_count,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
                SUM(total) as total_revenue
            FROM orders 
            WHERE DATE(created_at) = DATE('now')
        ")->fetch();

        $data = [
            'orders' => $orders,
            'stats' => $stats,
            'timestamp' => time(),
            'server_time' => date('Y-m-d H:i:s')
        ];

        echo "data: " . json_encode($data) . "\n\n";
        
        if (ob_get_level()) {
            ob_flush();
        }
        flush();
        
        sleep($sleepInterval);
        
    } catch (Exception $e) {
        echo "data: " . json_encode(['error' => $e->getMessage()]) . "\n\n";
        if (ob_get_level()) {
            ob_flush();
        }
        flush();
        break;
    }
}
?>