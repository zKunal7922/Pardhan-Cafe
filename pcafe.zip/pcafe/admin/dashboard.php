<?php 
require_once __DIR__.'/_guard.php'; 
$pdo = db(); 

// Handle status updates
if(isset($_GET['status'], $_GET['id'])) {
    $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([
        $_GET['status'], 
        (int)$_GET['id']
    ]); 
    header('Location: dashboard.php'); 
    exit;
} 

// Get orders with pagination
$page = (int)($_GET['page'] ?? 1);
$limit = 50;
$offset = ($page - 1) * $limit;

$filter = $_GET['filter'] ?? 'all';
$whereClause = '';
$params = [];

if($filter !== 'all') {
    $whereClause = 'WHERE status = ?';
    $params[] = $filter;
}

$orders = $pdo->prepare("SELECT * FROM orders $whereClause ORDER BY id DESC LIMIT $limit OFFSET $offset");
$orders->execute($params);
$orders = $orders->fetchAll();

// Get stats
$stats = $pdo->query("
    SELECT 
        COUNT(*) as total_orders,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
        COUNT(CASE WHEN status = 'preparing' THEN 1 END) as preparing_count,
        COUNT(CASE WHEN status = 'served' THEN 1 END) as served_count,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
        SUM(total) as total_revenue
    FROM orders 
    WHERE DATE(created_at) = DATE('now')
")->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Admin dashboard for managing orders">
    <title>Admin Dashboard — Pradhan Cafe</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="admin-header">
            <div class="header-left">
                <div class="brand">
                    <i class="fas fa-tachometer-alt"></i>
                    Dashboard
                </div>
                <div class="live-indicator" id="live-indicator">
                    <div class="pulse-dot"></div>
                    <span>Live Updates</span>
                </div>
            </div>
            
            <div class="header-actions">
                <a href="menu.php" class="btn secondary">
                    <i class="fas fa-utensils"></i>
                    Manage Menu
                </a>
                <a href="logout.php" class="btn secondary">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </header>

        <!-- Stats Overview -->
        <div class="stats-grid" id="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-receipt"></i>
                </div>
                <div class="stat-content">
                    <h3 id="total-orders"><?= $stats['total_orders'] ?></h3>
                    <p>Total Orders Today</p>
                </div>
            </div>
            
            <div class="stat-card pending">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-content">
                    <h3 id="pending-count"><?= $stats['pending_count'] ?></h3>
                    <p>Pending Orders</p>
                </div>
            </div>
            
            <div class="stat-card preparing">
                <div class="stat-icon">
                    <i class="fas fa-fire"></i>
                </div>
                <div class="stat-content">
                    <h3 id="preparing-count"><?= $stats['preparing_count'] ?></h3>
                    <p>Preparing</p>
                </div>
            </div>
            
            <div class="stat-card revenue">
                <div class="stat-icon">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="stat-content">
                    <h3 id="total-revenue"><?= currency($stats['total_revenue'] ?? 0) ?></h3>
                    <p>Today's Revenue</p>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <div class="card" style="padding: 1.5rem;">
                <div class="filters-header">
                    <h3>
                        <i class="fas fa-filter"></i>
                        Filter Orders
                    </h3>
                    <div class="auto-refresh">
                        <label class="switch">
                            <input type="checkbox" id="auto-refresh-toggle" checked>
                            <span class="slider"></span>
                        </label>
                        <span>Auto Refresh</span>
                    </div>
                </div>
                
                <div class="filter-buttons">
                    <a href="?filter=all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">
                        <i class="fas fa-list"></i>
                        All Orders
                    </a>
                    <a href="?filter=pending" class="filter-btn <?= $filter === 'pending' ? 'active' : '' ?>">
                        <i class="fas fa-clock"></i>
                        Pending
                    </a>
                    <a href="?filter=preparing" class="filter-btn <?= $filter === 'preparing' ? 'active' : '' ?>">
                        <i class="fas fa-fire"></i>
                        Preparing
                    </a>
                    <a href="?filter=served" class="filter-btn <?= $filter === 'served' ? 'active' : '' ?>">
                        <i class="fas fa-bell"></i>
                        Served
                    </a>
                    <a href="?filter=completed" class="filter-btn <?= $filter === 'completed' ? 'active' : '' ?>">
                        <i class="fas fa-check"></i>
                        Completed
                    </a>
                </div>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="orders-section">
            <div class="card">
                <div class="table-header">
                    <h3>
                        <i class="fas fa-clipboard-list"></i>
                        Recent Orders
                    </h3>
                    <div class="table-actions">
                        <button onclick="refreshOrders()" class="btn secondary">
                            <i class="fas fa-sync-alt" id="refresh-icon"></i>
                            Refresh
                        </button>
                    </div>
                </div>
                
                <div class="table-container" id="orders-table">
                    <?php if (empty($orders)): ?>
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h4>No Orders Found</h4>
                            <p>No orders match your current filter criteria.</p>
                        </div>
                    <?php else: ?>
                        <table class="orders-table">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Table</th>
                                    <th>Customer</th>
                                    <th>Phone</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Time</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="orders-tbody">
                                <?php foreach($orders as $order): ?>
                                    <tr class="order-row" data-order-id="<?= $order['id'] ?>" data-status="<?= $order['status'] ?>">
                                        <td class="order-id">#<?= $order['id'] ?></td>
                                        <td class="table-no">
                                            <span class="table-badge">
                                                <i class="fas fa-chair"></i>
                                                <?= htmlspecialchars($order['table_no']) ?>
                                            </span>
                                        </td>
                                        <td class="customer-name"><?= htmlspecialchars($order['customer_name']) ?></td>
                                        <td class="customer-phone"><?= htmlspecialchars($order['phone']) ?></td>
                                        <td class="order-total"><?= currency($order['total']) ?></td>
                                        <td class="order-status">
                                            <span class="status-badge status-<?= $order['status'] ?>">
                                                <i class="fas fa-circle"></i>
                                                <?= ucfirst($order['status']) ?>
                                            </span>
                                        </td>
                                        <td class="order-time">
                                            <?= date('g:i A', strtotime($order['created_at'])) ?>
                                        </td>
                                        <td class="order-actions">
                                            <div class="action-buttons">
                                                <a href="order.php?id=<?= $order['id'] ?>" class="action-btn view-btn" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="print_bill.php?id=<?= $order['id'] ?>" class="action-btn bill-btn" title="Download Bill">
                                                    <i class="fas fa-file-pdf"></i>
                                                </a>
                                                
                                                <?php if($order['status'] === 'pending'): ?>
                                                    <a href="?status=preparing&id=<?= $order['id'] ?>" class="action-btn preparing-btn" title="Mark as Preparing">
                                                        <i class="fas fa-fire"></i>
                                                    </a>
                                                <?php elseif($order['status'] === 'preparing'): ?>
                                                    <a href="?status=served&id=<?= $order['id'] ?>" class="action-btn served-btn" title="Mark as Served">
                                                        <i class="fas fa-bell"></i>
                                                    </a>
                                                <?php elseif($order['status'] === 'served'): ?>
                                                    <a href="?status=completed&id=<?= $order['id'] ?>" class="action-btn completed-btn" title="Mark as Completed">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        let eventSource = null;
        let autoRefresh = true;
        let lastUpdateTime = Date.now();

        // GSAP Animations
        gsap.timeline()
            .from(".admin-header", {duration: 0.8, y: -30, opacity: 0, ease: "power2.out"})
            .from(".stat-card", {duration: 0.6, y: 30, opacity: 0, stagger: 0.1, ease: "power2.out"}, "-=0.4")
            .from(".filters-section", {duration: 0.8, y: 20, opacity: 0, ease: "power2.out"}, "-=0.3")
            .from(".orders-section", {duration: 0.8, y: 20, opacity: 0, ease: "power2.out"}, "-=0.4");

        // Live updates using SSE
        function startLiveUpdates() {
            if (typeof(EventSource) !== "undefined" && autoRefresh) {
                eventSource = new EventSource('api/orders_stream.php');
                
                eventSource.onmessage = function(event) {
                    try {
                        const data = JSON.parse(event.data);
                        if (data.orders && data.stats) {
                            updateStats(data.stats);
                            updateOrdersTable(data.orders);
                            updateLiveIndicator(true);
                            lastUpdateTime = Date.now();
                        }
                    } catch (e) {
                        console.log('SSE parsing error:', e);
                    }
                };
                
                eventSource.onerror = function() {
                    console.log('SSE connection failed, switching to polling');
                    eventSource.close();
                    startPolling();
                };
            } else {
                startPolling();
            }
        }

        // Fallback polling
        function startPolling() {
            if (!autoRefresh) return;
            
            setInterval(async () => {
                try {
                    const response = await fetch('api/orders_stream.php');
                    const text = await response.text();
                    const dataMatch = text.match(/data: (.+)/);
                    if (dataMatch) {
                        const data = JSON.parse(dataMatch[1]);
                        if (data.orders && data.stats) {
                            updateStats(data.stats);
                            updateOrdersTable(data.orders);
                            updateLiveIndicator(true);
                            lastUpdateTime = Date.now();
                        }
                    }
                } catch (e) {
                    console.log('Polling error:', e);
                    updateLiveIndicator(false);
                }
            }, 5000);
        }

        // Update statistics
        function updateStats(stats) {
            document.getElementById('total-orders').textContent = stats.total_orders;
            document.getElementById('pending-count').textContent = stats.pending_count;
            document.getElementById('preparing-count').textContent = stats.preparing_count;
            document.getElementById('total-revenue').textContent = formatCurrency(stats.total_revenue || 0);
        }

        // Update orders table
        function updateOrdersTable(orders) {
            // For simplicity, we'll just highlight new/updated orders
            // In a full implementation, you'd diff and update specific rows
            const tbody = document.getElementById('orders-tbody');
            if (tbody) {
                // Add animation to indicate updates
                gsap.to(tbody, {duration: 0.3, backgroundColor: 'rgba(212, 175, 55, 0.1)', ease: "power2.out"})
                    .then(() => gsap.to(tbody, {duration: 0.5, backgroundColor: 'transparent', ease: "power2.out"}));
            }
        }

        // Update live indicator
        function updateLiveIndicator(isConnected) {
            const indicator = document.getElementById('live-indicator');
            if (isConnected) {
                indicator.classList.add('connected');
                indicator.classList.remove('disconnected');
            } else {
                indicator.classList.add('disconnected');
                indicator.classList.remove('connected');
            }
        }

        // Manual refresh
        function refreshOrders() {
            const icon = document.getElementById('refresh-icon');
            gsap.to(icon, {duration: 1, rotation: 360, ease: "power2.out"});
            window.location.reload();
        }

        // Auto refresh toggle
        document.getElementById('auto-refresh-toggle').addEventListener('change', function() {
            autoRefresh = this.checked;
            if (autoRefresh) {
                startLiveUpdates();
            } else {
                if (eventSource) eventSource.close();
                updateLiveIndicator(false);
            }
        });

        // Format currency
        function formatCurrency(amount) {
            return '₹' + parseFloat(amount).toFixed(2);
        }

        // Action button animations
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                gsap.to(this, {duration: 0.1, scale: 0.9, ease: "power2.out"})
                    .then(() => gsap.to(this, {duration: 0.2, scale: 1, ease: "bounce.out"}));
            });
        });

        // Initialize
        startLiveUpdates();
        
        // Connection status check
        setInterval(() => {
            const timeSinceUpdate = Date.now() - lastUpdateTime;
            if (timeSinceUpdate > 15000) { // 15 seconds without update
                updateLiveIndicator(false);
            }
        }, 5000);

        // Cleanup on page unload
        window.addEventListener('beforeunload', function() {
            if (eventSource) eventSource.close();
        });
    </script>

    <style>
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 2rem 0;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 2rem;
        }
        
        .header-actions {
            display: flex;
            gap: 1rem;
        }
        
        .live-indicator {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--bg-secondary);
            border-radius: 50px;
            border: 1px solid var(--glass-border);
            font-size: 0.9rem;
            color: var(--text-secondary);
        }
        
        .pulse-dot {
            width: 8px;
            height: 8px;
            background: var(--error);
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        .live-indicator.connected .pulse-dot {
            background: var(--success);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            padding: 2rem;
            display: flex;
            align-items: center;
            gap: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-glow);
        }
        
        .stat-card.pending {
            border-color: var(--warning);
        }
        
        .stat-card.preparing {
            border-color: var(--info);
        }
        
        .stat-card.revenue {
            border-color: var(--success);
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--gold-primary) 0%, #F4D03F 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        
        .stat-icon i {
            font-size: 1.5rem;
            color: var(--text-inverse);
        }
        
        .stat-content h3 {
            font-size: 2rem;
            margin: 0 0 0.25rem 0;
            color: var(--text-primary);
        }
        
        .stat-content p {
            margin: 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .filters-section {
            margin-bottom: 2rem;
        }
        
        .filters-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .auto-refresh {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 0.9rem;
            color: var(--text-secondary);
        }
        
        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }
        
        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--bg-tertiary);
            border: 1px solid var(--glass-border);
            transition: .4s;
            border-radius: 24px;
        }
        
        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 3px;
            bottom: 3px;
            background-color: var(--text-secondary);
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .slider {
            background-color: var(--gold-primary);
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
            background-color: var(--text-inverse);
        }
        
        .filter-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .filter-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .filter-btn:hover,
        .filter-btn.active {
            background: var(--gold-soft);
            color: var(--gold-primary);
            border-color: var(--gold-primary);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 2rem 2rem 1rem;
        }
        
        .table-container {
            padding: 0 2rem 2rem;
        }
        
        .orders-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .orders-table th {
            background: var(--bg-tertiary);
            color: var(--gold-primary);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid var(--glass-border);
        }
        
        .orders-table td {
            padding: 1rem;
            border-bottom: 1px solid var(--glass-border);
            vertical-align: middle;
        }
        
        .order-row:hover {
            background: var(--gold-soft);
        }
        
        .table-badge {
            background: var(--gold-soft);
            color: var(--gold-primary);
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .action-btn {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .view-btn {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
            border: 1px solid var(--info);
        }
        
        .bill-btn {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid var(--error);
        }
        
        .preparing-btn {
            background: rgba(245, 165, 36, 0.1);
            color: var(--warning);
            border: 1px solid var(--warning);
        }
        
        .served-btn {
            background: rgba(62, 207, 142, 0.1);
            color: var(--success);
            border: 1px solid var(--success);
        }
        
        .completed-btn {
            background: rgba(107, 114, 128, 0.1);
            color: var(--text-muted);
            border: 1px solid var(--text-muted);
        }
        
        .action-btn:hover {
            transform: scale(1.1);
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--text-secondary);
        }
        
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-muted);
        }
        
        .empty-state h4 {
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }
        
        @media (max-width: 768px) {
            .admin-header {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }
            
            .header-left {
                justify-content: space-between;
            }
            
            .filters-header {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }
            
            .filter-buttons {
                justify-content: center;
            }
            
            .orders-table {
                font-size: 0.8rem;
            }
            
            .orders-table th,
            .orders-table td {
                padding: 0.5rem;
            }
        }
    </style>
</body>
</html>