<?php 
require_once __DIR__.'/_guard.php'; 
$pdo = db(); 
$id = (int)($_GET['id'] ?? 0); 
$order = $pdo->query('SELECT * FROM orders WHERE id = ' . $id)->fetch(); 
$items = $pdo->query('SELECT * FROM order_items WHERE order_id = ' . $id)->fetchAll(); 

if (!$order) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Order details and bill management">
    <title>Order #<?= $id ?> — Pradhan Cafe Admin</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="order-header">
            <div class="header-left">
                <div class="brand">
                    <i class="fas fa-receipt"></i>
                    Order #<?= $id ?>
                </div>
                <div class="order-status-header">
                    <span class="status-badge status-<?= $order['status'] ?>">
                        <i class="fas fa-circle"></i>
                        <?= ucfirst($order['status']) ?>
                    </span>
                </div>
            </div>
            
            <div class="header-actions">
                <a href="print_bill.php?id=<?= $id ?>" class="btn" target="_blank">
                    <i class="fas fa-download"></i>
                    Download Bill
                </a>
                <a href="dashboard.php" class="btn secondary">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>
            </div>
        </header>

        <!-- Order Details Grid -->
        <div class="order-details-grid">
            <!-- Customer Information -->
            <div class="info-card" id="customer-info">
                <div class="card" style="padding: 2rem;">
                    <h3>
                        <i class="fas fa-user"></i>
                        Customer Information
                    </h3>
                    
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="info-label">Name:</span>
                            <span class="info-value"><?= htmlspecialchars($order['customer_name']) ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Phone:</span>
                            <span class="info-value"><?= htmlspecialchars($order['phone']) ?></span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Table:</span>
                            <span class="info-value">
                                <span class="table-badge">
                                    <i class="fas fa-chair"></i>
                                    <?= htmlspecialchars($order['table_no']) ?>
                                </span>
                            </span>
                        </div>
                        
                        <div class="info-item">
                            <span class="info-label">Order Time:</span>
                            <span class="info-value"><?= date('M j, Y g:i A', strtotime($order['created_at'])) ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Order Items -->
            <div class="items-card" id="order-items">
                <div class="card" style="padding: 2rem;">
                    <div class="items-header">
                        <h3>
                            <i class="fas fa-list-ul"></i>
                            Order Items
                        </h3>
                        <div class="items-count">
                            <span class="badge"><?= count($items) ?> items</span>
                        </div>
                    </div>
                    
                    <div class="items-list">
                        <?php 
                        $subtotal = 0;
                        foreach($items as $index => $item): 
                            $itemTotal = $item['price'] * $item['qty'];
                            $subtotal += $itemTotal;
                        ?>
                            <div class="order-item" data-item-index="<?= $index ?>">
                                <div class="item-image">
                                    <img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=80&h=80&fit=crop" 
                                         alt="<?= htmlspecialchars($item['item_name']) ?>">
                                </div>
                                
                                <div class="item-details">
                                    <h4 class="item-name"><?= htmlspecialchars($item['item_name']) ?></h4>
                                    <div class="item-meta">
                                        <span class="item-price"><?= currency($item['price']) ?> each</span>
                                        <span class="item-qty">×<?= $item['qty'] ?></span>
                                    </div>
                                </div>
                                
                                <div class="item-total">
                                    <span class="total-amount"><?= currency($itemTotal) ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="hr"></div>
                    
                    <div class="order-summary">
                        <div class="summary-row">
                            <span class="summary-label">Subtotal:</span>
                            <span class="summary-value"><?= currency($subtotal) ?></span>
                        </div>
                        
                        <div class="summary-row total">
                            <span class="summary-label">Total Amount:</span>
                            <span class="summary-value"><?= currency($order['total']) ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Order Timeline -->
        <div class="timeline-section">
            <div class="card" style="padding: 2rem;">
                <h3>
                    <i class="fas fa-clock"></i>
                    Order Timeline
                </h3>
                
                <div class="timeline">
                    <div class="timeline-item active">
                        <div class="timeline-icon">
                            <i class="fas fa-plus"></i>
                        </div>
                        <div class="timeline-content">
                            <h4>Order Placed</h4>
                            <p><?= date('M j, Y g:i A', strtotime($order['created_at'])) ?></p>
                        </div>
                    </div>
                    
                    <div class="timeline-item <?= in_array($order['status'], ['preparing', 'served', 'completed']) ? 'active' : '' ?>">
                        <div class="timeline-icon">
                            <i class="fas fa-fire"></i>
                        </div>
                        <div class="timeline-content">
                            <h4>Preparing</h4>
                            <p>Order is being prepared by our chefs</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item <?= in_array($order['status'], ['served', 'completed']) ? 'active' : '' ?>">
                        <div class="timeline-icon">
                            <i class="fas fa-bell"></i>
                        </div>
                        <div class="timeline-content">
                            <h4>Ready to Serve</h4>
                            <p>Order is ready and being served</p>
                        </div>
                    </div>
                    
                    <div class="timeline-item <?= $order['status'] === 'completed' ? 'active' : '' ?>">
                        <div class="timeline-icon">
                            <i class="fas fa-check"></i>
                        </div>
                        <div class="timeline-content">
                            <h4>Completed</h4>
                            <p>Order completed successfully</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <div class="actions-grid">
                <?php if($order['status'] === 'pending'): ?>
                    <a href="dashboard.php?status=preparing&id=<?= $id ?>" class="action-card preparing">
                        <i class="fas fa-fire"></i>
                        <span>Mark as Preparing</span>
                    </a>
                <?php elseif($order['status'] === 'preparing'): ?>
                    <a href="dashboard.php?status=served&id=<?= $id ?>" class="action-card served">
                        <i class="fas fa-bell"></i>
                        <span>Mark as Served</span>
                    </a>
                <?php elseif($order['status'] === 'served'): ?>
                    <a href="dashboard.php?status=completed&id=<?= $id ?>" class="action-card completed">
                        <i class="fas fa-check"></i>
                        <span>Mark as Completed</span>
                    </a>
                <?php endif; ?>
                
                <a href="print_bill.php?id=<?= $id ?>" class="action-card bill" target="_blank">
                    <i class="fas fa-file-pdf"></i>
                    <span>Generate Bill</span>
                </a>
                
                <button onclick="window.print()" class="action-card print">
                    <i class="fas fa-print"></i>
                    <span>Print Order</span>
                </button>
            </div>
        </div>
    </div>

    <script>
        // GSAP Animations
        gsap.timeline()
            .from(".order-header", {duration: 0.8, y: -30, opacity: 0, ease: "power2.out"})
            .from(".info-card", {duration: 0.8, x: -50, opacity: 0, ease: "power2.out"}, "-=0.4")
            .from(".items-card", {duration: 0.8, x: 50, opacity: 0, ease: "power2.out"}, "-=0.6")
            .from(".timeline-section", {duration: 0.8, y: 30, opacity: 0, ease: "power2.out"}, "-=0.4")
            .from(".order-item", {duration: 0.5, y: 20, opacity: 0, stagger: 0.1, ease: "power2.out"}, "-=0.3")
            .from(".quick-actions", {duration: 0.8, y: 30, opacity: 0, ease: "power2.out"}, "-=0.2");

        // Action card animations
        document.querySelectorAll('.action-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                gsap.to(this, {duration: 0.3, y: -4, scale: 1.02, ease: "power2.out"});
            });
            
            card.addEventListener('mouseleave', function() {
                gsap.to(this, {duration: 0.3, y: 0, scale: 1, ease: "power2.out"});
            });
            
            card.addEventListener('click', function(e) {
                gsap.to(this, {duration: 0.1, scale: 0.95, ease: "power2.out"})
                    .then(() => gsap.to(this, {duration: 0.2, scale: 1, ease: "bounce.out"}));
            });
        });

        // Timeline item animations
        document.querySelectorAll('.timeline-item.active').forEach((item, index) => {
            gsap.from(item, {
                duration: 0.6,
                scale: 0.8,
                opacity: 0,
                delay: 0.1 * index,
                ease: "back.out(1.7)"
            });
        });
    </script>

    <style>
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 2rem 0;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 2rem;
        }
        
        .header-actions {
            display: flex;
            gap: 1rem;
        }
        
        .order-status-header {
            display: flex;
            align-items: center;
        }
        
        .order-details-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        @media (max-width: 1024px) {
            .order-details-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .info-grid {
            display: grid;
            gap: 1.5rem;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
        
        .info-label {
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .info-value {
            color: var(--text-primary);
            font-weight: 600;
        }
        
        .table-badge {
            background: var(--gold-soft);
            color: var(--gold-primary);
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.9rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .items-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .badge {
            background: var(--gold-primary);
            color: var(--text-inverse);
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .order-item {
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 1rem;
            align-items: center;
            padding: 1.5rem 0;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .item-image img {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            object-fit: cover;
        }
        
        .item-name {
            margin: 0 0 0.5rem 0;
            color: var(--text-primary);
            font-size: 1.1rem;
        }
        
        .item-meta {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .item-price {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .item-qty {
            background: var(--gold-soft);
            color: var(--gold-primary);
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.8rem;
        }
        
        .total-amount {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--gold-primary);
        }
        
        .order-summary {
            padding-top: 1.5rem;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .summary-row.total {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--gold-primary);
            border-top: 2px solid var(--glass-border);
            padding-top: 1rem;
            margin-top: 1rem;
            margin-bottom: 0;
        }
        
        .timeline {
            margin-top: 2rem;
        }
        
        .timeline-item {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            position: relative;
            opacity: 0.5;
            transition: all 0.3s ease;
        }
        
        .timeline-item.active {
            opacity: 1;
        }
        
        .timeline-item:not(:last-child)::after {
            content: '';
            position: absolute;
            left: 20px;
            top: 50px;
            width: 2px;
            height: calc(100% + 1rem);
            background: var(--glass-border);
        }
        
        .timeline-item.active:not(:last-child)::after {
            background: var(--gold-primary);
        }
        
        .timeline-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--bg-tertiary);
            border: 2px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }
        
        .timeline-item.active .timeline-icon {
            background: var(--gold-primary);
            border-color: var(--gold-primary);
            color: var(--text-inverse);
        }
        
        .timeline-content h4 {
            margin: 0 0 0.25rem 0;
            color: var(--text-primary);
        }
        
        .timeline-content p {
            margin: 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .quick-actions {
            margin: 3rem 0;
        }
        
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .action-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            padding: 2rem;
            text-align: center;
            text-decoration: none;
            color: var(--text-primary);
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1rem;
        }
        
        .action-card i {
            font-size: 2rem;
            color: var(--gold-primary);
        }
        
        .action-card.preparing {
            border-color: var(--warning);
        }
        
        .action-card.preparing i {
            color: var(--warning);
        }
        
        .action-card.served {
            border-color: var(--success);
        }
        
        .action-card.served i {
            color: var(--success);
        }
        
        .action-card.completed {
            border-color: var(--text-muted);
        }
        
        .action-card.completed i {
            color: var(--text-muted);
        }
        
        .action-card.bill {
            border-color: var(--error);
        }
        
        .action-card.bill i {
            color: var(--error);
        }
        
        .action-card:hover {
            box-shadow: var(--shadow-glow);
        }
        
        @media (max-width: 768px) {
            .order-header {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }
            
            .header-left {
                justify-content: space-between;
            }
            
            .order-item {
                grid-template-columns: 1fr;
                gap: 1rem;
                text-align: center;
            }
            
            .actions-grid {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            }
            
            .action-card {
                padding: 1.5rem 1rem;
            }
        }
        
        @media print {
            .header-actions, .quick-actions, .timeline-section {
                display: none;
            }
            
            .order-details-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>