<?php 
require_once __DIR__.'/_guard.php'; 
$pdo = db(); 

// Handle form submissions
if($_SERVER['REQUEST_METHOD'] === 'POST') { 
    if(($_POST['action'] ?? '') === 'add') { 
        $name = trim($_POST['name']); 
        $price = (float)$_POST['price']; 
        $category = (int)$_POST['category_id']; 
        $image = null; 
        
        if(!empty($_FILES['image']['name'])) { 
            $filename = time() . '_' . preg_replace('/[^A-Za-z0-9_.-]/', '', $_FILES['image']['name']); 
            $uploadDir = __DIR__ . '/../public/uploads/';
            
            // Create uploads directory if it doesn't exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            if(move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $filename)) {
                $image = $filename; 
            }
        } 
        
        $pdo->prepare('INSERT INTO items(category_id, name, price, image) VALUES(?, ?, ?, ?)')->execute([
            $category, $name, $price, $image
        ]); 
        
        $message = 'Item added successfully!';
    } 
    
    if(($_POST['action'] ?? '') === 'toggle') { 
        $id = (int)$_POST['id']; 
        $status = (int)$_POST['is_active']; 
        $pdo->prepare('UPDATE items SET is_active = ? WHERE id = ?')->execute([$status, $id]); 
        
        $message = 'Item status updated successfully!';
    } 
}

$categories = $pdo->query('SELECT * FROM categories ORDER BY sort_order')->fetchAll(); 
$items = $pdo->query('SELECT i.*, c.name as category_name FROM items i JOIN categories c ON c.id = i.category_id ORDER BY c.sort_order, i.name')->fetchAll(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Menu management and item administration">
    <title>Menu Management — Pradhan Cafe Admin</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="menu-header">
            <div class="brand">
                <i class="fas fa-utensils"></i>
                Menu Management
            </div>
            <div class="header-actions">
                <a href="dashboard.php" class="btn secondary">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>
            </div>
        </header>

        <!-- Success Message -->
        <?php if(!empty($message)): ?>
            <div class="success-message" id="success-message">
                <i class="fas fa-check-circle"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <!-- Add Item Form -->
        <div class="add-item-section">
            <div class="card" style="padding: 2rem;">
                <div class="section-header">
                    <h3>
                        <i class="fas fa-plus-circle"></i>
                        Add New Item
                    </h3>
                    <p class="section-subtitle">Create a new menu item for your cafe</p>
                </div>
                
                <form method="post" enctype="multipart/form-data" class="add-item-form" id="add-item-form">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="category_id">
                                <i class="fas fa-folder"></i>
                                Category
                            </label>
                            <select name="category_id" id="category_id" required>
                                <option value="">Select Category</option>
                                <?php foreach($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="item_name">
                                <i class="fas fa-tag"></i>
                                Item Name
                            </label>
                            <input type="text" 
                                   id="item_name"
                                   name="name" 
                                   placeholder="Enter item name" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="price">
                                <i class="fas fa-rupee-sign"></i>
                                Price
                            </label>
                            <input type="number" 
                                   id="price"
                                   name="price" 
                                   step="0.01" 
                                   min="0"
                                   placeholder="0.00" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="image">
                                <i class="fas fa-image"></i>
                                Image (Optional)
                            </label>
                            <div class="file-upload">
                                <input type="file" 
                                       id="image"
                                       name="image" 
                                       accept="image/*"
                                       onchange="previewImage(this)">
                                <div class="file-upload-display">
                                    <div class="upload-placeholder" id="upload-placeholder">
                                        <i class="fas fa-cloud-upload-alt"></i>
                                        <span>Click to upload image</span>
                                    </div>
                                    <img id="image-preview" class="image-preview" style="display: none;">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn add-btn">
                            <i class="fas fa-plus"></i>
                            Add Item to Menu
                        </button>
                        <button type="reset" class="btn secondary" onclick="resetForm()">
                            <i class="fas fa-undo"></i>
                            Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Items Grid -->
        <div class="items-section">
            <div class="card">
                <div class="section-header" style="padding: 2rem 2rem 1rem;">
                    <h3>
                        <i class="fas fa-list"></i>
                        Current Menu Items
                    </h3>
                    <div class="items-stats">
                        <span class="badge">
                            <?= count($items) ?> total items
                        </span>
                        <span class="badge success">
                            <?= count(array_filter($items, fn($item) => $item['is_active'])) ?> active
                        </span>
                    </div>
                </div>
                
                <?php if (empty($items)): ?>
                    <div class="empty-state">
                        <i class="fas fa-utensils"></i>
                        <h4>No Menu Items</h4>
                        <p>Add your first menu item using the form above.</p>
                    </div>
                <?php else: ?>
                    <div class="items-grid" id="items-grid">
                        <?php foreach($items as $index => $item): ?>
                            <div class="menu-item-card <?= $item['is_active'] ? 'active' : 'inactive' ?>" data-item-id="<?= $item['id'] ?>">
                                <div class="item-image-container">
                                    <img src="<?= $item['image'] ? '../public/uploads/' . htmlspecialchars($item['image']) : 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=300&h=200&fit=crop' ?>" 
                                         alt="<?= htmlspecialchars($item['name']) ?>"
                                         class="item-image">
                                    
                                    <div class="item-status">
                                        <span class="status-indicator <?= $item['is_active'] ? 'active' : 'inactive' ?>">
                                            <i class="fas fa-circle"></i>
                                            <?= $item['is_active'] ? 'Active' : 'Hidden' ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="item-content">
                                    <div class="item-header">
                                        <h4 class="item-name"><?= htmlspecialchars($item['name']) ?></h4>
                                        <span class="item-price"><?= currency($item['price']) ?></span>
                                    </div>
                                    
                                    <div class="item-category">
                                        <i class="fas fa-folder"></i>
                                        <?= htmlspecialchars($item['category_name']) ?>
                                    </div>
                                    
                                    <div class="item-actions">
                                        <form method="post" style="display: inline;" onsubmit="return confirmToggle(this)">
                                            <input type="hidden" name="action" value="toggle">
                                            <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                            <input type="hidden" name="is_active" value="<?= $item['is_active'] ? 0 : 1 ?>">
                                            
                                            <button type="submit" class="action-btn toggle-btn <?= $item['is_active'] ? 'hide' : 'show' ?>">
                                                <i class="fas <?= $item['is_active'] ? 'fa-eye-slash' : 'fa-eye' ?>"></i>
                                                <?= $item['is_active'] ? 'Hide' : 'Show' ?>
                                            </button>
                                        </form>
                                        
                                        <button class="action-btn edit-btn" onclick="editItem(<?= $item['id'] ?>)">
                                            <i class="fas fa-edit"></i>
                                            Edit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // GSAP Animations
        gsap.timeline()
            .from(".menu-header", {duration: 0.8, y: -30, opacity: 0, ease: "power2.out"})
            .from(".add-item-section", {duration: 0.8, y: 30, opacity: 0, ease: "power2.out"}, "-=0.4")
            .from(".items-section", {duration: 0.8, y: 30, opacity: 0, ease: "power2.out"}, "-=0.6")
            .from(".menu-item-card", {duration: 0.5, y: 20, opacity: 0, stagger: 0.05, ease: "power2.out"}, "-=0.4");

        // Success message animation
        <?php if(!empty($message)): ?>
        gsap.from("#success-message", {duration: 0.5, x: 50, opacity: 0, ease: "power2.out", delay: 0.5});
        
        // Auto hide success message
        setTimeout(() => {
            gsap.to("#success-message", {duration: 0.5, x: 50, opacity: 0, ease: "power2.in"});
        }, 5000);
        <?php endif; ?>

        // Image preview function
        function previewImage(input) {
            const file = input.files[0];
            const preview = document.getElementById('image-preview');
            const placeholder = document.getElementById('upload-placeholder');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                    placeholder.style.display = 'none';
                }
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
                placeholder.style.display = 'flex';
            }
        }

        // Reset form function
        function resetForm() {
            document.getElementById('image-preview').style.display = 'none';
            document.getElementById('upload-placeholder').style.display = 'flex';
        }

        // Confirm toggle function
        function confirmToggle(form) {
            const action = form.querySelector('button').textContent.trim();
            return confirm(`Are you sure you want to ${action.toLowerCase()} this item?`);
        }

        // Edit item function (placeholder)
        function editItem(id) {
            alert('Edit functionality would be implemented here for item ID: ' + id);
        }

        // Form submission animation
        document.getElementById('add-item-form').addEventListener('submit', function(e) {
            const btn = this.querySelector('.add-btn');
            gsap.to(btn, {duration: 0.1, scale: 0.95, ease: "power2.out"})
                .then(() => gsap.to(btn, {duration: 0.2, scale: 1, ease: "bounce.out"}));
        });

        // Menu item card hover effects
        document.querySelectorAll('.menu-item-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                gsap.to(this, {duration: 0.3, y: -8, scale: 1.02, ease: "power2.out"});
            });
            
            card.addEventListener('mouseleave', function() {
                gsap.to(this, {duration: 0.3, y: 0, scale: 1, ease: "power2.out"});
            });
        });

        // Action button animations
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                gsap.to(this, {duration: 0.1, scale: 0.9, ease: "power2.out"})
                    .then(() => gsap.to(this, {duration: 0.2, scale: 1, ease: "bounce.out"}));
            });
        });
    </script>

    <style>
        .menu-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 2rem 0;
            border-bottom: 1px solid var(--glass-border);
            margin-bottom: 2rem;
        }
        
        .success-message {
            background: rgba(62, 207, 142, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-weight: 500;
        }
        
        .add-item-section {
            margin-bottom: 3rem;
        }
        
        .section-header {
            margin-bottom: 2rem;
        }
        
        .section-header h3 {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.5rem;
            color: var(--gold-primary);
        }
        
        .section-subtitle {
            color: var(--text-secondary);
            margin: 0;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        
        .form-group label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.75rem;
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 1rem;
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            border-color: var(--gold-primary);
            box-shadow: 0 0 0 3px var(--gold-soft);
        }
        
        .file-upload {
            position: relative;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-upload-display {
            width: 100%;
            height: 120px;
            border: 2px dashed var(--glass-border);
            border-radius: 12px;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .file-upload:hover .file-upload-display {
            border-color: var(--gold-primary);
            background: var(--gold-soft);
        }
        
        .upload-placeholder {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: var(--text-secondary);
            gap: 0.5rem;
        }
        
        .upload-placeholder i {
            font-size: 2rem;
        }
        
        .image-preview {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-start;
            flex-wrap: wrap;
        }
        
        .items-stats {
            display: flex;
            gap: 0.75rem;
        }
        
        .badge {
            background: var(--gold-primary);
            color: var(--text-inverse);
            padding: 0.25rem 0.75rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .badge.success {
            background: var(--success);
        }
        
        .items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 2rem;
            padding: 2rem;
        }
        
        .menu-item-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .menu-item-card.inactive {
            opacity: 0.6;
            filter: grayscale(0.5);
        }
        
        .menu-item-card:hover {
            box-shadow: var(--shadow-glow);
        }
        
        .item-image-container {
            position: relative;
            height: 200px;
            overflow: hidden;
        }
        
        .item-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .menu-item-card:hover .item-image {
            transform: scale(1.05);
        }
        
        .item-status {
            position: absolute;
            top: 1rem;
            right: 1rem;
        }
        
        .status-indicator {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            border: 1px solid var(--glass-border);
        }
        
        .status-indicator.active {
            color: var(--success);
            border-color: var(--success);
        }
        
        .status-indicator.inactive {
            color: var(--text-muted);
            border-color: var(--text-muted);
        }
        
        .item-content {
            padding: 1.5rem;
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .item-name {
            margin: 0;
            color: var(--text-primary);
            font-size: 1.1rem;
        }
        
        .item-price {
            color: var(--gold-primary);
            font-weight: 700;
            font-size: 1.2rem;
        }
        
        .item-category {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        
        .item-actions {
            display: flex;
            gap: 0.75rem;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .toggle-btn.hide {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid var(--error);
        }
        
        .toggle-btn.show {
            background: rgba(62, 207, 142, 0.1);
            color: var(--success);
            border: 1px solid var(--success);
        }
        
        .edit-btn {
            background: rgba(59, 130, 246, 0.1);
            color: var(--info);
            border: 1px solid var(--info);
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--text-secondary);
        }
        
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: var(--text-muted);
        }
        
        .empty-state h4 {
            margin-bottom: 0.5rem;
            color: var(--text-primary);
        }
        
        @media (max-width: 768px) {
            .menu-header {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                justify-content: stretch;
            }
            
            .form-actions .btn {
                flex: 1;
            }
            
            .items-grid {
                grid-template-columns: 1fr;
                padding: 1rem;
            }
            
            .item-header {
                flex-direction: column;
                gap: 0.5rem;
            }
        }
    </style>
</body>
</html>