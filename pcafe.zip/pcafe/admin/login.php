<?php 
require_once __DIR__.'/../db/init.php'; 

if(isset($_POST['user'], $_POST['pass'])) { 
    $adminUser = getenv('ADMIN_USER') ?: 'admin'; 
    $adminPass = getenv('ADMIN_PASS') ?: '1234'; 
    
    if($_POST['user'] === $adminUser && $_POST['pass'] === $adminPass) { 
        $_SESSION['admin'] = true; 
        header('Location: dashboard.php'); 
        exit; 
    } else {
        $error = 'Invalid credentials. Please try again.';
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Pradhan Cafe Admin Portal">
    <title>Admin Login — Pradhan Cafe</title>
    <link rel="stylesheet" href="../public/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="login-container">
        <div class="login-background">
            <div class="background-pattern"></div>
        </div>
        
        <div class="login-card" id="login-card">
            <div class="login-header">
                <div class="admin-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h1 class="login-title">Admin Portal</h1>
                <p class="login-subtitle">Pradhan Cafe Management</p>
            </div>
            
            <?php if(!empty($error)): ?>
                <div class="error-message" id="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>
            
            <form method="post" class="login-form" id="login-form">
                <div class="form-group">
                    <label for="user">
                        <i class="fas fa-user"></i>
                        Username
                    </label>
                    <input type="text" 
                           id="user"
                           name="user" 
                           placeholder="Enter admin username" 
                           required 
                           autocomplete="username"
                           value="<?= htmlspecialchars($_POST['user'] ?? '') ?>">
                </div>
                
                <div class="form-group">
                    <label for="pass">
                        <i class="fas fa-lock"></i>
                        Password
                    </label>
                    <div class="password-field">
                        <input type="password" 
                               id="pass"
                               name="pass" 
                               placeholder="Enter admin password" 
                               required 
                               autocomplete="current-password">
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i class="fas fa-eye" id="password-icon"></i>
                        </button>
                    </div>
                </div>
                
                <button type="submit" class="btn login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Sign In</span>
                    <div class="btn-loader">
                        <div class="loading"></div>
                    </div>
                </button>
            </form>
            
            <div class="login-footer">
                <p>
                    <i class="fas fa-info-circle"></i>
                    Default: admin / 1234
                </p>
            </div>
        </div>
    </div>

    <script>
        // GSAP Animations
        gsap.timeline()
            .from("#login-card", {duration: 1, y: 50, opacity: 0, ease: "power2.out"})
            .from(".admin-icon", {duration: 0.8, scale: 0, rotation: 180, ease: "back.out(1.7)"}, "-=0.5")
            .from(".login-title", {duration: 0.6, y: 20, opacity: 0, ease: "power2.out"}, "-=0.3")
            .from(".form-group", {duration: 0.5, y: 20, opacity: 0, stagger: 0.1, ease: "power2.out"}, "-=0.2");

        // Error message animation
        <?php if(!empty($error)): ?>
        gsap.from("#error-message", {duration: 0.5, x: -20, opacity: 0, ease: "power2.out", delay: 0.5});
        <?php endif; ?>

        // Form submission
        document.getElementById('login-form').addEventListener('submit', function(e) {
            const btn = this.querySelector('.login-btn');
            const btnText = btn.querySelector('span');
            const loader = btn.querySelector('.btn-loader');
            
            btn.disabled = true;
            btnText.style.opacity = '0';
            loader.style.display = 'block';
            
            gsap.to(btn, {duration: 0.3, scale: 0.95, ease: "power2.out"});
        });

        // Password toggle
        function togglePassword() {
            const passwordField = document.getElementById('pass');
            const passwordIcon = document.getElementById('password-icon');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                passwordIcon.className = 'fas fa-eye-slash';
            } else {
                passwordField.type = 'password';
                passwordIcon.className = 'fas fa-eye';
            }
        }

        // Input focus animations
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('focus', function() {
                gsap.to(this.parentElement, {duration: 0.3, scale: 1.02, ease: "power2.out"});
            });
            
            input.addEventListener('blur', function() {
                gsap.to(this.parentElement, {duration: 0.3, scale: 1, ease: "power2.out"});
            });
        });
    </script>

    <style>
        body {
            overflow: hidden;
        }
        
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 2rem;
        }
        
        .login-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--bg-primary) 0%, var(--bg-secondary) 100%);
            z-index: -1;
        }
        
        .background-pattern {
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 25% 25%, var(--gold-soft) 0%, transparent 50%),
                radial-gradient(circle at 75% 75%, var(--gold-soft) 0%, transparent 50%);
            animation: patternFloat 20s ease-in-out infinite;
        }
        
        @keyframes patternFloat {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(2deg); }
        }
        
        .login-card {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 32px;
            padding: 3rem 2.5rem;
            box-shadow: var(--shadow-xl);
            width: 100%;
            max-width: 450px;
            position: relative;
        }
        
        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--gold-primary), transparent);
            border-radius: 32px 32px 0 0;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .admin-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, var(--gold-primary) 0%, #F4D03F 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow-glow);
        }
        
        .admin-icon i {
            font-size: 2rem;
            color: var(--text-inverse);
        }
        
        .login-title {
            font-family: 'Playfair Display', serif;
            font-size: 2rem;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--text-primary) 0%, var(--gold-primary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .login-subtitle {
            color: var(--text-secondary);
            margin-bottom: 0;
        }
        
        .error-message {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid var(--error);
            color: var(--error);
            padding: 1rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .login-form {
            margin-bottom: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 1rem;
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 16px;
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-group input:focus {
            border-color: var(--gold-primary);
            box-shadow: 0 0 0 3px var(--gold-soft);
        }
        
        .password-field {
            position: relative;
        }
        
        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .password-toggle:hover {
            color: var(--gold-primary);
            background: var(--gold-soft);
        }
        
        .login-btn {
            width: 100%;
            padding: 1rem 1.5rem;
            font-size: 1.1rem;
            position: relative;
            overflow: hidden;
        }
        
        .login-btn:disabled {
            cursor: not-allowed;
            opacity: 0.7;
        }
        
        .btn-loader {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: none;
        }
        
        .login-footer {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid var(--glass-border);
        }
        
        .login-footer p {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        @media (max-width: 640px) {
            .login-container {
                padding: 1rem;
            }
            
            .login-card {
                padding: 2rem 1.5rem;
            }
            
            .login-title {
                font-size: 1.5rem;
            }
        }
    </style>
</body>
</html>