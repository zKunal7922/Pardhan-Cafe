<?php
session_start();
define('DB_DRIVER','sqlite');
define('DB_SQLITE_PATH', __DIR__.'/cafedb.sqlite');
function db(){ static $pdo; if($pdo) return $pdo; $pdo=new PDO('sqlite:'.DB_SQLITE_PATH); $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
  $pdo->exec("CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,sort_order INTEGER DEFAULT 0)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY AUTOINCREMENT,category_id INTEGER,name TEXT,price REAL,image TEXT,is_active INTEGER DEFAULT 1)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,table_no TEXT,customer_name TEXT,phone TEXT,status TEXT DEFAULT 'pending',total REAL DEFAULT 0,created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY AUTOINCREMENT,order_id INTEGER,item_id INTEGER,item_name TEXT,price REAL,qty INTEGER)");
  $c=$pdo->query("SELECT COUNT(*) c FROM categories")->fetch()['c']??0; if(!$c){ 
    $cats=['Brain Attacker','Shakes','Coffee','Burger','Pizza','Fries']; $i=1; 
    $s=$pdo->prepare('INSERT INTO categories(name,sort_order) VALUES(?,?)'); 
    foreach($cats as $x){$s->execute([$x,$i++]);}
    
    $get=$pdo->prepare('SELECT id FROM categories WHERE name=?'); 
    $ins=$pdo->prepare('INSERT INTO items(category_id,name,price) VALUES(?,?,?)');
    
    $items = [
      // Brain Attacker (Beverages)
      ['Brain Attacker','Ice Tea',79],
      ['Brain Attacker','Lemon Ice Tea',85],
      ['Brain Attacker','Green Tea',65],
      ['Brain Attacker','Masala Chai',45],
      ['Brain Attacker','Fresh Lime Water',55],
      ['Brain Attacker','Mint Lemonade',70],
      
      // Shakes
      ['Shakes','Oreo Shake',120],
      ['Shakes','Chocolate Shake',110],
      ['Shakes','Vanilla Shake',100],
      ['Shakes','Strawberry Shake',115],
      ['Shakes','Mango Shake',125],
      ['Shakes','Banana Shake',105],
      ['Shakes','Kit-Kat Shake',140],
      
      // Coffee
      ['Coffee','Cold Coffee',85],
      ['Coffee','Hot Coffee',65],
      ['Coffee','Cappuccino',95],
      ['Coffee','Latte',105],
      ['Coffee','Espresso',75],
      ['Coffee','Americano',80],
      ['Coffee','Mocha',115],
      
      // Burger
      ['Burger','Veg Burger',89],
      ['Burger','Cheese Burger',110],
      ['Burger','Paneer Burger',125],
      ['Burger','Aloo Tikki Burger',95],
      ['Burger','Mushroom Burger',115],
      ['Burger','Double Cheese Burger',145],
      
      // Pizza
      ['Pizza','Margherita Pizza',180],
      ['Pizza','Veggie Supreme',220],
      ['Pizza','Paneer Tikka Pizza',240],
      ['Pizza','Mushroom Pizza',200],
      ['Pizza','Corn & Cheese Pizza',190],
      ['Pizza','Mexican Green Wave',260],
      
      // Fries
      ['Fries','Regular Fries',60],
      ['Fries','Cheese Fries',85],
      ['Fries','Peri Peri Fries',75],
      ['Fries','Loaded Fries',120],
      ['Fries','Masala Fries',70],
      ['Fries','Garlic Fries',80]
    ];
    
    foreach($items as $r){
      $get->execute([$r[0]]);
      $cid=$get->fetch()['id'];
      $ins->execute([$cid,$r[1],$r[2]]);
    } 
  }
  return $pdo;
}
function currency($n){return '₹'.number_format($n,2);} ?>