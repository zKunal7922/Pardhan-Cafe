<?php 
require_once __DIR__.'/../db/init.php'; 
$pdo = db(); 

if(!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle add to cart
if($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') { 
    $id = (int)($_POST['id'] ?? 0); 
    $qty = max(1, (int)($_POST['qty'] ?? 1)); 
    $result = $pdo->query('SELECT * FROM items WHERE id = ' . $id)->fetch(); 
    
    if($result) { 
        if(empty($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id] = [
                'id' => $id,
                'name' => $result['name'],
                'price' => $result['price'],
                'qty' => 0
            ];
        }
        $_SESSION['cart'][$id]['qty'] += $qty; 
    } 
    header('Location: cart.php'); 
    exit; 
}

// Handle remove from cart
if(isset($_GET['remove'])) { 
    unset($_SESSION['cart'][(int)$_GET['remove']]); 
    header('Location: cart.php'); 
    exit; 
}

$cart = array_values($_SESSION['cart']); 
$total = 0; 
foreach($cart as $item) {
    $total += $item['price'] * $item['qty'];
} 
$table = $_SESSION['table_no'] ?? ''; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Review your order and complete checkout">
    <title>Your Cart — Pradhan Cafe</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="brand">
                <i class="fas fa-shopping-cart"></i>
                Your Cart
            </div>
            <div style="margin-left: auto;">
                <a href="index.php" class="btn secondary">
                    <i class="fas fa-plus"></i>
                    Add More Items
                </a>
            </div>
        </header>

        <?php if(!$cart): ?>
            <!-- Empty Cart State -->
            <div class="card" style="padding: 4rem; text-align: center;" id="empty-cart">
                <div class="empty-cart-content">
                    <i class="fas fa-shopping-cart" style="font-size: 4rem; color: var(--text-muted); margin-bottom: 1.5rem;"></i>
                    <h2 style="color: var(--text-secondary); margin-bottom: 1rem;">Your Cart is Empty</h2>
                    <p style="color: var(--text-muted); margin-bottom: 2rem;">
                        Discover our premium selection of coffees, snacks, and delicious treats
                    </p>
                    <a href="index.php" class="btn">
                        <i class="fas fa-coffee"></i>
                        Browse Menu
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Cart with Items -->
            <div class="cart-layout">
                <!-- Cart Items -->
                <div class="cart-items" id="cart-items">
                    <div class="card" style="padding: 2rem;">
                        <h3 style="margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;">
                            <i class="fas fa-list"></i>
                            Order Summary
                        </h3>
                        
                        <div class="cart-table">
                            <?php foreach($cart as $index => $item): ?>
                                <div class="cart-item" data-item-id="<?= $item['id'] ?>">
                                    <div class="item-details">
                                        <div class="item-image">
                                            <img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=100&h=100&fit=crop" 
                                                 alt="<?= htmlspecialchars($item['name']) ?>">
                                        </div>
                                        <div class="item-info">
                                            <h4><?= htmlspecialchars($item['name']) ?></h4>
                                            <p class="item-price"><?= currency($item['price']) ?> each</p>
                                        </div>
                                    </div>
                                    
                                    <div class="quantity-display">
                                        <span class="qty-label">Qty:</span>
                                        <span class="qty-value"><?= $item['qty'] ?></span>
                                    </div>
                                    
                                    <div class="item-total">
                                        <span class="total-price"><?= currency($item['price'] * $item['qty']) ?></span>
                                    </div>
                                    
                                    <div class="item-actions">
                                        <a href="?remove=<?= $item['id'] ?>" class="remove-btn" title="Remove from cart">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="hr"></div>
                        
                        <div class="cart-total">
                            <div class="total-row">
                                <span class="total-label">Grand Total:</span>
                                <span class="total-amount"><?= currency($total) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Checkout Form -->
                <div class="checkout-form" id="checkout-form">
                    <div class="card" style="padding: 2rem;">
                        <h3 style="margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;">
                            <i class="fas fa-user"></i>
                            Customer Details
                        </h3>
                        
                        <form method="post" action="place_order.php" class="checkout-form-inner">
                            <div class="form-group">
                                <label for="table_no">
                                    <i class="fas fa-chair"></i>
                                    Table Number
                                </label>
                                <input type="text" 
                                       id="table_no"
                                       name="table_no" 
                                       value="<?= htmlspecialchars($table) ?>" 
                                       required 
                                       placeholder="Enter table number">
                            </div>
                            
                            <div class="form-group">
                                <label for="customer_name">
                                    <i class="fas fa-user"></i>
                                    Customer Name
                                </label>
                                <input type="text" 
                                       id="customer_name"
                                       name="customer_name" 
                                       required 
                                       placeholder="Enter your name">
                            </div>
                            
                            <div class="form-group">
                                <label for="phone">
                                    <i class="fas fa-phone"></i>
                                    Phone Number
                                </label>
                                <input type="tel" 
                                       id="phone"
                                       name="phone" 
                                       placeholder="Enter phone number">
                            </div>
                            
                            <div class="form-group">
                                <label class="payment-method">
                                    <input type="radio" name="pay" value="counter" checked>
                                    <span class="radio-custom"></span>
                                    <i class="fas fa-cash-register"></i>
                                    Pay at Counter
                                </label>
                            </div>
                            
                            <div class="order-summary-sticky">
                                <div class="summary-line">
                                    <span>Items: <?= count($cart) ?></span>
                                    <span><?= currency($total) ?></span>
                                </div>
                                <button type="submit" class="btn checkout-btn">
                                    <i class="fas fa-check"></i>
                                    Place Order (<?= currency($total) ?>)
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // GSAP Animations - only animate elements that exist
        const timeline = gsap.timeline();
        timeline.from(".header", {duration: 0.8, y: -30, opacity: 0, ease: "power2.out"});
        
        // Only animate cart elements if they exist
        if(document.querySelector(".cart-items")) {
            timeline.from(".cart-items", {duration: 0.8, x: -50, opacity: 0, ease: "power2.out"}, "-=0.4");
        }
        
        if(document.querySelector(".checkout-form")) {
            timeline.from(".checkout-form", {duration: 0.8, x: 50, opacity: 0, ease: "power2.out"}, "-=0.6");
        }
        
        if(document.querySelectorAll(".cart-item").length > 0) {
            timeline.from(".cart-item", {duration: 0.6, y: 20, opacity: 0, stagger: 0.1, ease: "power2.out"}, "-=0.4");
        }
        
        // If cart is empty, animate empty state
        if(document.querySelector("#empty-cart")) {
            timeline.from("#empty-cart", {duration: 0.8, y: 30, opacity: 0, ease: "power2.out"}, "-=0.4");
        }

        // Remove button animations
        document.querySelectorAll('.remove-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const cartItem = this.closest('.cart-item');
                const href = this.getAttribute('href');
                
                gsap.to(cartItem, {
                    duration: 0.5,
                    x: -100,
                    opacity: 0,
                    ease: "power2.in",
                    onComplete: () => {
                        window.location.href = href;
                    }
                });
            });
        });

        // Form submission animation
        document.querySelector('.checkout-form-inner')?.addEventListener('submit', function(e) {
            const btn = this.querySelector('.checkout-btn');
            gsap.to(btn, {duration: 0.1, scale: 0.95, ease: "power2.out"})
                .then(() => gsap.to(btn, {duration: 0.2, scale: 1, ease: "bounce.out"}));
        });
    </script>

    <style>
        .cart-layout {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-top: 2rem;
        }
        
        @media (max-width: 1024px) {
            .cart-layout {
                grid-template-columns: 1fr;
            }
        }
        
        .cart-item {
            display: grid;
            grid-template-columns: 1fr auto auto auto;
            gap: 1rem;
            align-items: center;
            padding: 1.5rem 0;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .cart-item:last-child {
            border-bottom: none;
        }
        
        .item-details {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .item-image img {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            object-fit: cover;
        }
        
        .item-info h4 {
            margin: 0 0 0.25rem 0;
            font-size: 1rem;
            color: var(--text-primary);
        }
        
        .item-price {
            margin: 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .quantity-display {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
        }
        
        .qty-label {
            font-size: 0.8rem;
            color: var(--text-secondary);
        }
        
        .qty-value {
            background: var(--gold-soft);
            color: var(--gold-primary);
            border-radius: 8px;
            padding: 0.25rem 0.5rem;
            font-weight: 600;
            min-width: 30px;
            text-align: center;
        }
        
        .item-total {
            text-align: right;
        }
        
        .total-price {
            font-weight: 600;
            color: var(--gold-primary);
            font-size: 1.1rem;
        }
        
        .remove-btn {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
            border: 1px solid var(--error);
            border-radius: 8px;
            padding: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .remove-btn:hover {
            background: var(--error);
            color: white;
            transform: scale(1.1);
        }
        
        .cart-total {
            text-align: right;
            padding-top: 1rem;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 1.25rem;
            font-weight: 700;
        }
        
        .total-label {
            color: var(--text-primary);
        }
        
        .total-amount {
            color: var(--gold-primary);
            font-size: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            color: var(--text-primary);
            font-weight: 500;
        }
        
        .payment-method {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
            background: var(--gold-soft);
            border: 1px solid var(--gold-primary);
            border-radius: 12px;
            cursor: pointer;
        }
        
        .radio-custom {
            width: 20px;
            height: 20px;
            border: 2px solid var(--gold-primary);
            border-radius: 50%;
            position: relative;
            flex-shrink: 0;
        }
        
        input[type="radio"] {
            display: none;
        }
        
        input[type="radio"]:checked + .radio-custom::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 10px;
            height: 10px;
            background: var(--gold-primary);
            border-radius: 50%;
        }
        
        .order-summary-sticky {
            position: sticky;
            bottom: 0;
            background: var(--bg-secondary);
            padding: 1.5rem;
            margin: -2rem -2rem -2rem -2rem;
            border-top: 1px solid var(--glass-border);
            border-radius: 0 0 24px 24px;
        }
        
        .summary-line {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .checkout-btn {
            width: 100%;
            font-size: 1.1rem;
            padding: 1rem;
        }
        
        @media (max-width: 768px) {
            .cart-item {
                grid-template-columns: 1fr auto;
                gap: 0.75rem;
            }
            
            .quantity-display,
            .item-total {
                grid-column: 1 / -1;
                justify-self: start;
                margin-top: 0.5rem;
            }
            
            .item-actions {
                grid-row: 1;
                grid-column: 2;
            }
        }
    </style>
</body>
</html>