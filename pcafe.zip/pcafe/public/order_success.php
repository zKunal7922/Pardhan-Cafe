<?php 
require_once __DIR__.'/../db/init.php'; 
$pdo = db(); 
$id = (int)($_GET['id'] ?? 0); 
$order = $pdo->query('SELECT * FROM orders WHERE id = ' . $id)->fetch(); 

if (!$order) {
    header('Location: index.php');
    exit;
}

// Get order items
$orderItems = $pdo->query('SELECT * FROM order_items WHERE order_id = ' . $id)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Order confirmation and live status updates">
    <title>Order Confirmation — Pradhan Cafe</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Success Header -->
        <div class="success-header" id="success-header">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1 class="success-title">Order Placed Successfully!</h1>
            <p class="success-subtitle">Thank you for choosing Pradhan Cafe</p>
        </div>

        <!-- Order Details -->
        <div class="order-details-layout">
            <!-- Main Order Info -->
            <div class="order-info" id="order-info">
                <div class="card" style="padding: 2rem;">
                    <div class="order-header">
                        <h2>
                            <i class="fas fa-receipt"></i>
                            Order #<?= $order['id'] ?>
                        </h2>
                        <div class="order-status">
                            <span class="status-badge status-<?= $order['status'] ?>" id="order-status">
                                <i class="fas fa-clock" id="status-icon"></i>
                                <span id="status-text"><?= ucfirst($order['status']) ?></span>
                            </span>
                        </div>
                    </div>
                    
                    <div class="hr"></div>
                    
                    <div class="order-meta">
                        <div class="meta-grid">
                            <div class="meta-item">
                                <i class="fas fa-chair"></i>
                                <div>
                                    <span class="meta-label">Table</span>
                                    <span class="meta-value"><?= htmlspecialchars($order['table_no']) ?></span>
                                </div>
                            </div>
                            
                            <div class="meta-item">
                                <i class="fas fa-user"></i>
                                <div>
                                    <span class="meta-label">Customer</span>
                                    <span class="meta-value"><?= htmlspecialchars($order['customer_name']) ?></span>
                                </div>
                            </div>
                            
                            <div class="meta-item">
                                <i class="fas fa-phone"></i>
                                <div>
                                    <span class="meta-label">Phone</span>
                                    <span class="meta-value"><?= htmlspecialchars($order['phone']) ?></span>
                                </div>
                            </div>
                            
                            <div class="meta-item">
                                <i class="fas fa-clock"></i>
                                <div>
                                    <span class="meta-label">Ordered</span>
                                    <span class="meta-value"><?= date('M j, Y g:i A', strtotime($order['created_at'])) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="hr"></div>
                    
                    <!-- Order Items -->
                    <div class="order-items">
                        <h3>
                            <i class="fas fa-list"></i>
                            Ordered Items
                        </h3>
                        
                        <div class="items-list">
                            <?php foreach($orderItems as $item): ?>
                                <div class="order-item">
                                    <div class="item-details">
                                        <span class="item-name"><?= htmlspecialchars($item['item_name']) ?></span>
                                        <span class="item-price"><?= currency($item['price']) ?> each</span>
                                    </div>
                                    <div class="item-qty">×<?= $item['qty'] ?></div>
                                    <div class="item-total"><?= currency($item['price'] * $item['qty']) ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="order-total">
                            <div class="total-row">
                                <span>Grand Total:</span>
                                <span class="total-amount"><?= currency($order['total']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Status Timeline -->
            <div class="status-timeline" id="status-timeline">
                <div class="card" style="padding: 2rem;">
                    <h3>
                        <i class="fas fa-hourglass-half"></i>
                        Order Progress
                    </h3>
                    
                    <div class="timeline">
                        <div class="timeline-item active" data-status="pending">
                            <div class="timeline-icon">
                                <i class="fas fa-receipt"></i>
                            </div>
                            <div class="timeline-content">
                                <h4>Order Received</h4>
                                <p>Your order has been received and is being processed</p>
                            </div>
                        </div>
                        
                        <div class="timeline-item" data-status="preparing">
                            <div class="timeline-icon">
                                <i class="fas fa-fire"></i>
                            </div>
                            <div class="timeline-content">
                                <h4>Preparing</h4>
                                <p>Our chefs are preparing your delicious items</p>
                            </div>
                        </div>
                        
                        <div class="timeline-item" data-status="served">
                            <div class="timeline-icon">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div class="timeline-content">
                                <h4>Ready to Serve</h4>
                                <p>Your order is ready and will be served shortly</p>
                            </div>
                        </div>
                        
                        <div class="timeline-item" data-status="completed">
                            <div class="timeline-icon">
                                <i class="fas fa-check"></i>
                            </div>
                            <div class="timeline-content">
                                <h4>Completed</h4>
                                <p>Enjoy your meal!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="order-actions" id="order-actions">
            <a href="index.php" class="btn">
                <i class="fas fa-coffee"></i>
                Order More Items
            </a>
            <button onclick="window.print()" class="btn secondary">
                <i class="fas fa-print"></i>
                Print Receipt
            </button>
        </div>
    </div>

    <script>
        let currentStatus = '<?= $order['status'] ?>';
        let eventSource = null;
        let pollInterval = null;

        // GSAP Animations
        const tl = gsap.timeline();
        tl.from("#success-header", {duration: 1, y: -50, opacity: 0, ease: "bounce.out"})
          .from("#order-info", {duration: 0.8, x: -50, opacity: 0, ease: "power2.out"}, "-=0.5")
          .from("#status-timeline", {duration: 0.8, x: 50, opacity: 0, ease: "power2.out"}, "-=0.6")
          .from("#order-actions", {duration: 0.6, y: 30, opacity: 0, ease: "power2.out"}, "-=0.3");

        // Success icon animation
        gsap.to(".success-icon i", {
            duration: 2,
            rotation: 360,
            scale: 1.1,
            ease: "power2.inOut",
            repeat: -1,
            yoyo: true,
            repeatDelay: 3
        });

        // Update order status
        function updateOrderStatus(newStatus, animate = true) {
            if (newStatus === currentStatus) return;
            
            currentStatus = newStatus;
            
            // Update status badge
            const statusBadge = document.getElementById('order-status');
            const statusText = document.getElementById('status-text');
            const statusIcon = document.getElementById('status-icon');
            
            statusBadge.className = `status-badge status-${newStatus}`;
            statusText.textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
            
            // Update icon based on status
            const iconMap = {
                pending: 'fas fa-clock',
                preparing: 'fas fa-fire',
                served: 'fas fa-bell',
                completed: 'fas fa-check'
            };
            statusIcon.className = iconMap[newStatus] || 'fas fa-clock';
            
            // Update timeline
            updateTimeline(newStatus, animate);
            
            if (animate) {
                // Pulse animation
                gsap.to(statusBadge, {duration: 0.3, scale: 1.1, ease: "power2.out"})
                    .then(() => gsap.to(statusBadge, {duration: 0.3, scale: 1, ease: "power2.out"}));
            }
        }

        // Update timeline based on status
        function updateTimeline(status, animate = true) {
            const statusOrder = ['pending', 'preparing', 'served', 'completed'];
            const currentIndex = statusOrder.indexOf(status);
            
            document.querySelectorAll('.timeline-item').forEach((item, index) => {
                const isActive = index <= currentIndex;
                
                if (isActive && !item.classList.contains('active')) {
                    item.classList.add('active');
                    if (animate) {
                        gsap.from(item, {duration: 0.5, scale: 0.8, ease: "back.out(1.7)"});
                    }
                } else if (!isActive) {
                    item.classList.remove('active');
                }
            });
        }

        // Server-Sent Events for live updates
        function startSSE() {
            if (typeof(EventSource) !== "undefined") {
                eventSource = new EventSource('../admin/api/orders_stream.php');
                
                eventSource.onmessage = function(event) {
                    try {
                        const data = JSON.parse(event.data);
                        if (data.orders) {
                            const order = data.orders.find(o => o.id == <?= $order['id'] ?>);
                            if (order && order.status !== currentStatus) {
                                updateOrderStatus(order.status);
                            }
                        }
                    } catch (e) {
                        console.log('SSE parsing error:', e);
                    }
                };
                
                eventSource.onerror = function() {
                    console.log('SSE connection failed, switching to polling');
                    eventSource.close();
                    startPolling();
                };
            } else {
                startPolling();
            }
        }

        // Fallback polling
        function startPolling() {
            pollInterval = setInterval(async () => {
                try {
                    const response = await fetch('../admin/api/orders_stream.php');
                    const text = await response.text();
                    const dataMatch = text.match(/data: (.+)/);
                    if (dataMatch) {
                        const data = JSON.parse(dataMatch[1]);
                        if (data.orders) {
                            const order = data.orders.find(o => o.id == <?= $order['id'] ?>);
                            if (order && order.status !== currentStatus) {
                                updateOrderStatus(order.status);
                            }
                        }
                    }
                } catch (e) {
                    console.log('Polling error:', e);
                }
            }, 5000);
        }

        // Initialize
        updateTimeline(currentStatus, false);
        startSSE();

        // Cleanup on page unload
        window.addEventListener('beforeunload', function() {
            if (eventSource) eventSource.close();
            if (pollInterval) clearInterval(pollInterval);
        });
    </script>

    <style>
        .success-header {
            text-align: center;
            margin: 3rem 0;
        }
        
        .success-icon {
            margin-bottom: 1rem;
        }
        
        .success-icon i {
            font-size: 4rem;
            color: var(--success);
        }
        
        .success-title {
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }
        
        .success-subtitle {
            color: var(--text-secondary);
            font-size: 1.1rem;
        }
        
        .order-details-layout {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin: 2rem 0;
        }
        
        @media (max-width: 1024px) {
            .order-details-layout {
                grid-template-columns: 1fr;
            }
        }
        
        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .order-header h2 {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--gold-primary);
        }
        
        .meta-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .meta-item i {
            color: var(--gold-primary);
            font-size: 1.2rem;
            width: 20px;
        }
        
        .meta-label {
            display: block;
            font-size: 0.9rem;
            color: var(--text-secondary);
        }
        
        .meta-value {
            display: block;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .order-items h3 {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .order-item {
            display: grid;
            grid-template-columns: 1fr auto auto;
            gap: 1rem;
            align-items: center;
            padding: 1rem 0;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .item-name {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .item-price {
            font-size: 0.9rem;
            color: var(--text-secondary);
        }
        
        .item-qty {
            background: var(--gold-soft);
            color: var(--gold-primary);
            padding: 0.25rem 0.5rem;
            border-radius: 8px;
            font-weight: 600;
            text-align: center;
            min-width: 40px;
        }
        
        .item-total {
            font-weight: 600;
            color: var(--gold-primary);
            text-align: right;
        }
        
        .order-total {
            border-top: 2px solid var(--glass-border);
            margin-top: 1rem;
            padding-top: 1rem;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            font-size: 1.2rem;
            font-weight: 700;
        }
        
        .total-amount {
            color: var(--gold-primary);
        }
        
        .timeline {
            margin-top: 1.5rem;
        }
        
        .timeline-item {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            position: relative;
            opacity: 0.5;
            transition: all 0.3s ease;
        }
        
        .timeline-item.active {
            opacity: 1;
        }
        
        .timeline-item:not(:last-child)::after {
            content: '';
            position: absolute;
            left: 20px;
            top: 50px;
            width: 2px;
            height: calc(100% + 1rem);
            background: var(--glass-border);
        }
        
        .timeline-item.active:not(:last-child)::after {
            background: var(--gold-primary);
        }
        
        .timeline-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--bg-tertiary);
            border: 2px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }
        
        .timeline-item.active .timeline-icon {
            background: var(--gold-primary);
            border-color: var(--gold-primary);
            color: var(--text-inverse);
        }
        
        .timeline-content h4 {
            margin: 0 0 0.25rem 0;
            color: var(--text-primary);
        }
        
        .timeline-content p {
            margin: 0;
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .order-actions {
            text-align: center;
            margin: 3rem 0;
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        @media print {
            .order-actions, .status-timeline {
                display: none;
            }
            
            .order-details-layout {
                grid-template-columns: 1fr;
            }
        }
    </style>
</body>
</html>