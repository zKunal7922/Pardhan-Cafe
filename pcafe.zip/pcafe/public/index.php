<?php 
require_once __DIR__.'/../db/init.php'; 
$pdo = db(); 

// Handle table selection
if(isset($_GET['table'])) {
    $_SESSION['table_no'] = preg_replace('/[^0-9A-Za-z\-]/', '', $_GET['table']);
}

// Handle clear table
if(isset($_GET['clear_table'])) {
    unset($_SESSION['table_no']);
    header('Location: index.php');
    exit;
}

// Get categories and items
$cats = $pdo->query('SELECT * FROM categories ORDER BY sort_order, name')->fetchAll(); 
$items = $pdo->query('SELECT i.*, c.name cname FROM items i JOIN categories c ON c.id = i.category_id WHERE is_active = 1 ORDER BY c.sort_order, i.name')->fetchAll(); 

// Group items by category
$grouped = []; 
foreach($items as $item) {
    $grouped[$item['cname']][] = $item;
} 

// Count cart items
$cart_count = 0; 
if(!empty($_SESSION['cart'])) {
    foreach($_SESSION['cart'] as $cart_item) {
        $cart_count += $cart_item['qty'];
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Premium cafe experience with authentic flavors and modern ambiance">
    <title>Pradhan Cafe — Premium Menu Experience</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/all.min.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <div class="brand" id="cafe-logo">PRADHAN CAFE</div>
            
            <div style="display: flex; gap: 1rem; align-items: center; margin-left: auto;">
                <!-- Table Selection -->
                <?php if(!empty($_SESSION['table_no'])): ?>
                    <div class="table-info">
                        <span class="status-badge status-served">
                            <i class="fas fa-chair"></i>
                            Table: <?= $_SESSION['table_no'] ?>
                        </span>
                        <a href="?clear_table=1" class="change-table-btn" title="Change Table">
                            <i class="fas fa-edit"></i>
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-selection">
                        <form method="get" class="table-form">
                            <div class="table-input-group">
                                <select name="table" class="table-select" required>
                                    <option value="">🪑 Select Your Table</option>
                                    <?php for($i = 1; $i <= 20; $i++): ?>
                                        <option value="<?= $i ?>">Table <?= $i ?></option>
                                    <?php endfor; ?>
                                </select>
                                <button type="submit" class="btn secondary table-set-btn">
                                    <i class="fas fa-check"></i>
                                    Confirm
                                </button>
                            </div>
                        </form>
                        <div class="table-help">
                            <i class="fas fa-info-circle"></i>
                            Please select your table number to start ordering
                        </div>
                    </div>
                <?php endif; ?>
                
            </div>
        </header>

        <!-- Hero Section -->
        <section class="hero">
            <h1 class="hero-title" id="hero-title">Premium Cafe Experience</h1>
            <p class="hero-subtitle" id="hero-subtitle">
                Discover authentic flavors crafted with passion, served in a modern ambiance
            </p>
        </section>

        <!-- Menu Layout -->
        <div class="menu">
            <!-- Categories Sidebar -->
            <aside class="categories" id="categories-sidebar">
                <?php foreach($cats as $cat): ?>
                    <a href="#c-<?= $cat['id'] ?>" class="category-link" data-category="<?= $cat['id'] ?>">
                        <i class="fas fa-coffee"></i>
                        <?= htmlspecialchars($cat['name']) ?>
                    </a>
                <?php endforeach; ?>
                
                <div class="hr"></div>
                
                <div class="sidebar-stats">
                    <p style="color: var(--text-secondary); font-size: 0.9rem; text-align: center;">
                        <i class="fas fa-utensils"></i>
                        <?= count($items) ?> Premium Items
                    </p>
                </div>
            </aside>

            <!-- Items Grid -->
            <main class="items" id="items-container">
                <?php foreach($cats as $cat): ?>
                    <section id="c-<?= $cat['id'] ?>" class="category-section">
                        <h2 class="category-title">
                            <i class="fas fa-star"></i>
                            <?= htmlspecialchars($cat['name']) ?>
                        </h2>
                        
                        <div class="grid">
                            <?php if(!empty($grouped[$cat['name']])): ?>
                                <?php foreach($grouped[$cat['name']] as $item): ?>
                                    <div class="item" data-item-id="<?= $item['id'] ?>">
                                        <div class="item-image">
                                            <img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=300&fit=crop" 
                                                 alt="<?= htmlspecialchars($item['name']) ?>"
                                                 loading="lazy">
                                            <div class="item-overlay">
                                                <i class="fas fa-eye"></i>
                                            </div>
                                        </div>
                                        
                                        <div class="info">
                                            <div class="item-header">
                                                <h3 class="item-name"><?= htmlspecialchars($item['name']) ?></h3>
                                                <span class="price"><?= currency($item['price']) ?></span>
                                            </div>
                                            
                                            <form method="post" action="cart.php" class="add-to-cart-form">
                                                <input type="hidden" name="action" value="add">
                                                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                                
                                                <div class="quantity-controls">
                                                    <label for="qty-<?= $item['id'] ?>" style="color: var(--text-secondary); font-size: 0.9rem;">Quantity:</label>
                                                    <div class="quantity-input">
                                                        <button type="button" class="qty-btn minus" onclick="changeQty(<?= $item['id'] ?>, -1)">
                                                            <i class="fas fa-minus"></i>
                                                        </button>
                                                        <input type="number" 
                                                               id="qty-<?= $item['id'] ?>"
                                                               name="qty" 
                                                               value="1" 
                                                               min="1" 
                                                               max="10"
                                                               class="qty-input">
                                                        <button type="button" class="qty-btn plus" onclick="changeQty(<?= $item['id'] ?>, 1)">
                                                            <i class="fas fa-plus"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                
                                                <button type="submit" class="btn add-btn">
                                                    <i class="fas fa-plus"></i>
                                                    Add to Cart
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-category">
                                    <i class="fas fa-coffee"></i>
                                    <p>Coming soon...</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>
                <?php endforeach; ?>
            </main>
        </div>
    </div>

    <!-- Cart FAB -->
    <a href="cart.php" class="cart" id="cart-fab">
        <i class="fas fa-shopping-cart"></i>
        <span>Cart</span>
        <span class="cart-count" id="cart-count"><?= $cart_count ?></span>
    </a>

    <script>
        // GSAP Animations
        gsap.registerPlugin();

        // Page load animations
        gsap.timeline()
            .from("#cafe-logo", {duration: 1, y: -50, opacity: 0, ease: "bounce.out"})
            .from("#hero-title", {duration: 0.8, y: 30, opacity: 0, ease: "power2.out"}, "-=0.5")
            .from("#hero-subtitle", {duration: 0.6, y: 20, opacity: 0, ease: "power2.out"}, "-=0.3")
            .from("#categories-sidebar", {duration: 0.8, x: -50, opacity: 0, ease: "power2.out"}, "-=0.4")
            .from(".item", {duration: 0.6, y: 30, opacity: 0, stagger: 0.1, ease: "power2.out"}, "-=0.4");

        // Logo hover animation
        document.getElementById('cafe-logo').addEventListener('mouseenter', function() {
            gsap.to(this, {duration: 0.3, scale: 1.05, ease: "power2.out"});
        });
        
        document.getElementById('cafe-logo').addEventListener('mouseleave', function() {
            gsap.to(this, {duration: 0.3, scale: 1, ease: "power2.out"});
        });

        // Cart pulse animation when items added
        function pulseCart() {
            gsap.to("#cart-fab", {duration: 0.3, scale: 1.1, ease: "power2.out"})
                .then(() => gsap.to("#cart-fab", {duration: 0.3, scale: 1, ease: "power2.out"}));
        }

        // Quantity controls
        function changeQty(itemId, delta) {
            const input = document.getElementById(`qty-${itemId}`);
            let newValue = parseInt(input.value) + delta;
            newValue = Math.max(1, Math.min(10, newValue));
            input.value = newValue;
        }

        // Form submission animation
        document.querySelectorAll('.add-to-cart-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const btn = this.querySelector('.add-btn');
                gsap.to(btn, {duration: 0.1, scale: 0.95, ease: "power2.out"})
                    .then(() => gsap.to(btn, {duration: 0.2, scale: 1, ease: "bounce.out"}));
                
                // Pulse cart after brief delay
                setTimeout(pulseCart, 200);
            });
        });

        // Smooth scrolling for category links
        document.querySelectorAll('.category-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const target = document.getElementById(targetId);
                if (target) {
                    target.scrollIntoView({behavior: 'smooth', block: 'start'});
                }
            });
        });

        // Item hover effects
        document.querySelectorAll('.item').forEach(item => {
            item.addEventListener('mouseenter', function() {
                gsap.to(this, {duration: 0.3, y: -8, ease: "power2.out"});
            });
            
            item.addEventListener('mouseleave', function() {
                gsap.to(this, {duration: 0.3, y: 0, ease: "power2.out"});
            });
        });
    </script>

    <style>
        .category-section {
            margin-bottom: 3rem;
        }
        
        .category-title {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
            color: var(--gold-primary);
            border-bottom: 2px solid var(--glass-border);
            padding-bottom: 0.75rem;
        }
        
        .item-image {
            position: relative;
            overflow: hidden;
        }
        
        .item-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .item:hover .item-overlay {
            opacity: 1;
        }
        
        .item-overlay i {
            color: var(--gold-primary);
            font-size: 2rem;
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .quantity-controls {
            margin-bottom: 1rem;
        }
        
        .quantity-input {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .qty-btn {
            background: var(--bg-tertiary);
            border: 1px solid var(--glass-border);
            color: var(--text-primary);
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .qty-btn:hover {
            background: var(--gold-primary);
            color: var(--text-inverse);
        }
        
        .qty-input {
            width: 60px;
            text-align: center;
            background: var(--bg-secondary);
            border: 1px solid var(--glass-border);
            border-radius: 8px;
            padding: 0.5rem;
            color: var(--text-primary);
        }
        
        .empty-category {
            text-align: center;
            padding: 3rem;
            color: var(--text-secondary);
            grid-column: 1 / -1;
        }
        
        .empty-category i {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--gold-primary);
        }
        
        .sidebar-stats {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--glass-border);
        }
    </style>
</body>
</html>